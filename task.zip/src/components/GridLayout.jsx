import React, { useEffect, useState } from "react";
import { Row, Col, Container } from "reactstrap";
import { Fragment } from "react";
import "./style.css";
// import { ReactMouseSelect } from "react-mouse-select";

const GridLayout = () => {
  
  const sizes = ["tiny", "small", "medium", "large", "huge"];
  const colors = [
    "navy",
    "blue",
    "aqua",
    "teal",
    "olive",
    "green",
    "lime",
    "yellow",
    "orange",
    "red",
    "maroon",
    "fuchsia",
    "purple",
    "silver",
    "gray",
    "black",
  ];
  const fruits = [
    "apple",
    "banana",
    "watermelon",
    "orange",
    "peach",
    "tangerine",
    "pear",
    "kiwi",
    "mango",
    "pineapple",
  ];

  const items = sizes.reduce(
    (items, size) => [
      ...items,
      ...fruits.reduce(
        (acc, fruit) => [
          ...acc,
          ...colors.reduce(
            (acc, color) => [
              ...acc,
              {
                name: `${size} ${color} ${fruit}`,
                color,
              },
            ],
            []
          ),
        ],
        []
      ),
    ],
    []
  );

  var [listOfItems, setListOfItems] = useState([]);
  // console.log(listOfItems);
  var unselected = "List__item List__item--";
  var selected = "List__item List__item--";

  const handleClick = (itemName, event) => {
    event.currentTarget.classList.add(
      'selected',
    );

    var dummy;
    if (listOfItems.length > 0) {
      listOfItems.map((list, index) => {
        if (list === itemName) {
          dummy = index;
        }
      });
      // console.log("dummy:", dummy);
    }

    if (dummy === undefined) {
      setListOfItems((oldArray) => [...oldArray, itemName]);
    } else {
      let dummyArray = [...listOfItems];
      dummyArray.splice(dummy, 1);
      setListOfItems(dummyArray);

      event.currentTarget.classList.remove(
        'selected',
      );
    }
  };

  useEffect(() => {
    // console.log("List of Items", listOfItems);
    console.log("rerenders")
  }, [listOfItems]);

  return (
    <div>
      {/* <Container>
        <Row>
          <Col className="bg-light border">.col</Col>
        </Row>
        <Row>
          <Col className="bg-light border">.col</Col>
          <Col className="bg-light border">.col</Col>
          <Col className="bg-light border">.col</Col>
          <Col className="bg-light border">.col</Col>
        </Row>
        <Row>
          <Col className="bg-light border" xs="3">
            .col-3
          </Col>
          <Col className="bg-light border" xs="auto">
            .col-auto - variable width content
          </Col>
          <Col className="bg-light border" xs="3">
            .col-3
          </Col>
        </Row>
        <Row>
          <Col className="bg-light border" xs="6">
            .col-6
          </Col>
          <Col className="bg-light border" xs="6">
            .col-6
          </Col>
        </Row>
        <Row>
          <Col className="bg-light border" sm="4" xs="6">
            .col-6 .col-sm-4
          </Col>
          <Col className="bg-light border" sm="4" xs="6">
            .col-6 .col-sm-4
          </Col>
          <Col className="bg-light border" sm="4">
            .col-sm-4
          </Col>
        </Row>
        <Row>
          <Col
            className="bg-light border"
            sm={{
              offset: 1,
              order: 2,
              size: 6,
            }}
          >
            .col-sm-6 .order-sm-2 .offset-sm-1
          </Col>
        </Row>
        <Row>
          <Col
            className="bg-light border"
            md={{
              offset: 3,
              size: 6,
            }}
            sm="12"
          >
            .col-sm-12 .col-md-6 .offset-md-3
          </Col>
        </Row>
        <Row>
          <Col
            className="bg-light border"
            sm={{
              offset: 1,
              size: "auto",
            }}
          >
            .col-sm-auto .offset-sm-1
          </Col>
          <Col
            className="bg-light border"
            sm={{
              offset: 1,
              size: "auto",
            }}
          >
            .col-sm-auto .offset-sm-1
          </Col>
        </Row>
      </Container> */}

      <Row className="mx-5">
      {(listOfItems.length>0) &&    <h4 className="mt-3"> Items Selected</h4> }
        {listOfItems !== [] &&
          listOfItems?.map((items, index) => {
            return (
              <Col xl="2" key={index}>
                <p className="text-start">
                  {index + 1}. {items}{" "}
                </p>
              </Col>
            );
          })}
      </Row>

      <Fragment>
        <ul className="List">
          {items.map((item) => (
            <li
              style={{ cursor: "pointer" }}
              onClick={(event) => handleClick(item.name,event)}
              key={item.name}
              className={`List__item List__item--${item.color}`}
              // { listOfItems.length===0 ?
              //   `List__item List__item--${item.color}`
              //   :
              //    listOfItems.map((list) => {
              //   if (list == item.name) {
              //     return `List__item List__item--${item.color} selected`;
              //   }
              //    else {
              //     return `List__item List__item--${item.color}`;
              //   }
              // })}
            >
              {item.name}
            </li>
          ))}
        </ul>
      </Fragment>
    </div>
  );
};

export default GridLayout;
